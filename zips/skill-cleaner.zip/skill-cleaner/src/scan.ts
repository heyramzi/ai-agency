import { existsSync } from "node:fs";
import { homedir } from "node:os";
import { basename, resolve } from "node:path";
import { analyze } from "./analyze.js";
import { danglingLinks, dedupe, defaultRoots, walkSkills } from "./discover.js";
import { parseSkill, str } from "./parse.js";
import { isMarketplaceClone, keepNewestPluginVersions } from "./plugins.js";
import { checkSkill } from "./rules.js";
import { readLedger, unusedFindings } from "./usage.js";
import type { Report, Skill } from "./types.js";

export function scan(
  roots: string[] = [],
  opts: { home?: string; allRuntimes?: boolean; usage?: string } = {},
): Report {
  const home = opts.home ?? homedir();
  const targets = (
    roots.length > 0
      ? roots.map((r) => resolve(r))
      : defaultRoots(process.cwd(), home, { allRuntimes: opts.allRuntimes })
  ).filter((r) => existsSync(r));

  const located = keepNewestPluginVersions(
    targets.flatMap((root) => walkSkills(root, home)).filter((item) => !isMarketplaceClone(item.realPath)),
  );
  const skills: Skill[] = [];
  const findings = [];

  for (const [realPath, group] of dedupe(located)) {
    const first = group[0];
    if (!first) continue;
    // Prefer the reachable path with a repo behind it, so a skill linked from a
    // home directory into a checkout is attributed to the checkout.
    const primary = group.find((item) => item.repo !== null) ?? first;
    try {
      const skill = parseSkill({ ...primary, realPath });
      skills.push(skill);
      // Vendor content is not a lint target: a plugin's authoring is its
      // vendor's to fix, and unactionable findings bury the actionable ones.
      // Plugins still count in `analyze`, where they collide with local skills.
      if (skill.origin !== "plugin") findings.push(...checkSkill(skill));
    } catch (error) {
      findings.push({
        code: "unreadable",
        severity: "error" as const,
        message: `Could not be read: ${error instanceof Error ? error.message : String(error)}`,
        paths: [realPath],
      });
    }
  }

  findings.push(...analyze(skills, targets.flatMap((root) => danglingLinks(root))));

  // What ran is evidence no file carries, so it arrives from the invocation
  // ledger rather than from the walk. The path is always explicit: a scan that
  // silently read the caller's real ledger would make its own tests depend on
  // how the machine running them has been used.
  if (opts.usage) findings.push(...unusedFindings(skills, readLedger(opts.usage)));

  // Aligning a name to its directory is only a one-outcome repair while that
  // directory name is free. `CLIs/umami` already had an `analytics/umami`
  // registered, and applying the fix turned a cosmetic warning into a
  // duplicate-name error, where the runtime silently drops one of the two.
  // Judged here because a single skill cannot see the rest of the registry.
  const taken = new Set(skills.map((skill) => str(skill.frontmatter.name)));
  for (const finding of findings) {
    if (finding.code !== "name-dir-mismatch" || !finding.fixable) continue;
    const skill = skills.find((candidate) => candidate.realPath === finding.paths[0]);
    if (skill && taken.has(basename(skill.dir))) finding.fixable = false;
  }

  return { scanned: targets, skills, findings };
}
