# Healing

Open this when a learning has no obvious home, when a skill's log needs tending or when a file is
over its ceiling.

## Home of each fact

Specificity wins: the narrowest file whose job already covers it, since that's the one a reader
opens when it matters.

| The learning is about | Home |
| --- | --- |
| how one task is done | the skill for that task |
| a mechanical coding mistake (a pattern a parser can see) | a lint rule, hook or typecheck flag, never prose |
| a constraint every skill in a domain hits | a rule scoped to that domain |
| the repo's shape, commands, conventions | `CLAUDE.md` / `AGENTS.md` |
| how one project looks or moves (a value, surface, curve he corrected) | that repo's `DESIGN.md`, by `ui-design`'s `references/design-taste.md` |
| an external system's behaviour | the skill that talks to it |
| a one-off about this conversation | nowhere |

A learning homed too high (one API's pagination in a root `CLAUDE.md`) costs every session.
A learning in 2 places: the copies drift and the reader can't tell which is current, so a second mention
becomes a pointer. A file that mirrors another opens by naming its source; update the source first.

## Leave alone

- A failure that was the model's fault and not the file's. The instruction was correct and clear, and a
  caveat only lengthens the file.
- A preference stated once. Wait for the second time.
- Anything the code already says. Document why this way, what was tried and abandoned, and
  which external system lies about itself. Grep the implementation before calling an entry
  unowned: 2 DepthFlow rules read homeless and were verbatim in `loop.ts`.

## Entries

Weak: "Be careful with the API rate limits." and "Fixed a bug in the upload path." (a
changelog). Strong: "The export endpoint returns 200 with an
empty body while the job runs, so a naive read stores an empty file and reports success. Poll
`status` until `complete` first." It names the symptom, the false signal and the action.

Format, newest first:
`- YYYY-MM-DD: <what went wrong or was assumed> <what to do instead>. [ask: <the ask that caused it>]`

An entry is one line of 240 characters at most, opening with the rule. The entry carries the rule and one checkable
anchor (the error string, the threshold, the flag); the story belongs in git. `heal.cjs log`
refuses longer (`--long` overrides). Keep the ask when a prompt caused the failure, because the
wording that broke the skill is the only input that proves the edit worked; `check` warns on a log
of 5 or more entries with none (on 5 Sep 2026 the field was absent from all 758 entries in 34 logs).

## Where a log lives

No promise, closing step or verification item: the standing self-healing rule covers every
skill. A log is `## Learned Patterns`, last in the file, seeded with real entries and never empty
(an empty log teaches the reader to skip the section). Past a handful it moves to
`references/learned-patterns.md`, and the body keeps a one-line pointer.

## The hooks' queue

`heal-stop` blocks a session's stop on its lessons, and `heal-end` writes what the session left
unsettled to `~/.claude/heal/proposals/`, from every repo. A session settles a signal by saying
`healed [id]: <path>` after the fix, or `not a lesson [id]: <why>`. An unnamed edit only settles
the signals of the skill or agent it lands in. `node scripts/heal-proposals.mjs pending` rescans each
pending proposal with today's scanner, closes the ones that come back empty (noise a filter has
since learned), and lists the rest. Settle each down the ladder, then
`heal-proposals.mjs close <file> healed|dismissed <why>`. 9 days of `Command "skool" not found`
from one scheduled job sat in that folder with nothing reading it (28 Oct 2026).

## Healing without bloat

- An edit leaves the file no longer than it found it, unless the case is really new.
- A learning repeated in 3 or more files becomes one rule, and the copies become pointers.
- An entry stays in the log 30 days at most. By then it's either true, so it goes into the body
  as the rule, or it isn't (the tool, flag or file it names is gone, or the body already says
  it), so it's deleted. `check` fails a log holding one, `fold` lists them, and neither rewrites
  prose.
- Past `logMaxEntries` (`ai-doc/limits.json`) a log is a second body wherever it sits: fold,
  don't raise the number. `audit` fails it.
- There is no `learned-patterns-archive.md`. 15 of them reached 5,296 lines holding 67
  rules never folded anywhere; `audit` fails one.

## Over the ceiling: restructure, don't shave

The author, 14 Sep 2026, watching a session shave sentences off `skool` to fit a new command under the
250-line cap: *"instead of trimming things just to refactor so that you just keep the essence and
key value"* and *"sometimes it's better to rework than to cut off, because you might lose value and
in what you keep there might be fluff"*. Read the whole body first and look for 3 shapes (all were in
`skool`):

- The same claim twice, in different words 3 lines apart; each edit read only its own paragraph.
- Several paragraphs on one subject, each ending with its own pointer to the same reference
  (5 on pushing a course, each "see classroom.md"). Make one section, keep the rules, one pointer.
- A rule whose evidence outgrew it. The incident belongs in the reference, the rule in the body.
  4 lines of what happened to 1 of what to do has the ratio backwards.

A restructure that doesn't end shorter hasn't found the fluff.
