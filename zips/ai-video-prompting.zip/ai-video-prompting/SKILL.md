---
name: ai-video-prompting
license: CC-BY-4.0 (attribution required - Serge Shima, github.com/smixs/visual-skills)
description: Appends new failure modes to its own pattern list after each run. Use this skill whenever the user asks to create, improve, audit, or split prompts for AI video generators (Seedance, Kling, Veo, Runway, Luma, Pika, Sora, any image-to-video system). The skill also covers storyboards, shot lists, director treatments, dynamic montage, multi-clip story structure, camera direction, lighting, blocking, pacing, character continuity, dialogue, and sound design. Trigger even when the user says things like "придумай сцену для видео", "разбей на склейки", "сделай раскадровку", "улучши промпт для Kling", "переведи сценарий в промпты", "как снять X в AI-видео", or shares a prompt and asks to fix it.
---

# AI Director, Screenwriter & Editor

Hybrid role. You direct (see frame, emotion, motivated camera), write (build beat, action, consequence, final image), and edit (cut rhythm, protect continuity, drive montage). Prompt engineering is fourth — it serves the first three.

A beautiful frame without dramaturgy is wallpaper. A dramaturgically clean prompt without details is mush. The whole craft of this skill lives in the reference files. The body of this SKILL.md is intentionally thin so you cannot fake a result by reading it alone.

## Route first, and the first question is whether a model should render this at all

**A generated clip re-draws every pixel of every frame.** So anything that has to stay identical to
a source file, land on a named frame, or come out with a true alpha channel belongs in Remotion and
the `motion-broll` skill, not here. Generation is for the shot that never existed: a place, a face,
an object in motion, a mood. Everything typographic, diagrammatic or keyed is drawn, not generated.

The one route back to alpha from a generator is a green screen prompted deliberately and keyed
afterwards, and it is worse than drawing the same thing. Reach for it only when the subject could
not be drawn.

Then:

- **No idea or script yet** (a concept, a Big Idea, an ad scenario, not a prompt): `video-script` for
  the doctrine and `video-hooks` for the open. Come back once there is something to shoot.
- **The clip serves a sentence in a video you are cutting**: `motion-broll` owns the clock, the
  coverage plan and the register. Get the beat and its frame count from there, then come back here
  for the prompt.
- **Still keyframes or plates** to feed the pipeline: `youtube-thumbnail` for the image style.
- **A script or scene exists and needs prompts** - this skill. Continue below.

---

# Mandatory reading order — DO NOT WRITE A PROMPT WITHOUT THIS

Past attempts to write prompts directly from this skill body produced lazy, mush-prone results. The fix is structural: the process lives only in the reference files, and you load them in this order before producing output. Skipping a step **silently** degrades the result — the model cannot tell that a shot is wallpaper, only the writer can, and only by applying the rules from these files.

For every video prompt request, load the files in this order:

### Step 1 — always read first → [dramaturgy.md](references/dramaturgy.md)

Scene formula. Details Law (the second core law, most violated). Murch Rule of Six. Three-jobs rule. Five anchors. Blocking, staging, environment as pressure. Three-layer storyboard. 14-field shot card. Rhythm ladder. Dramaturgy check.

You cannot decide whether a prompt is ready without running the dramaturgy check from this file.

### Step 2 — always read second → [universal-rules.md](references/universal-rules.md)

U1–U12 universal rules that apply to every video model: prompt skeleton, weight-at-start, show-don't-tell, lens language, character anchor, contradictions, duration discipline, final image rule, three-detail check.

### Step 3 — pick the model and read **one** model file

Use this short selector. The full reasoning is in the chosen file.

| Cue from the user / task | Read |
|---|---|
| Seedance, ByteDance, Doubao, Jimeng, multi-shot in one clip, `--resolution`, `--duration`, `--camerafixed`, "Cut to", `@img1`, fast multi-shot drama | [seedance.md](references/seedance.md) |
| **Seedance 2.5 production work**: 30s single-pass, 50-slot reference kits, video editing / partial re-render, extension, Ultra Long (30-180s), 3D blockout / green screen, `@Image N`, `{ }` dialogue markers | [seedance.md](references/seedance.md) **+** [seedance-25.md](references/seedance-25.md) |
| Kling, Kuaishou, Element Binding, Motion Brush, Motion Control, dedicated negative prompt field, **Kling 3.0 multi-shot with `[Character A: ...]` labels, native dialogue + lip-sync, 15s, Turbo (cheap lip-sync), Omni (references + editing, 4K)** | [kling.md](references/kling.md) |
| Veo, Google video, dialogue / lip-sync, JSON prompts, synchronized SFX, commercial polish with voiceover | [veo.md](references/veo.md) |

Default if nothing in the request hints at a model:
- Multi-shot narrative or fast montage drama → Seedance, or Kling 3.0 if dialogue is involved.
- Dialogue / commercial polish / synchronized SFX → Veo, or Kling 3.0 for multi-character dialogue scenes up to 15s.
- Character consistency across many social clips → Kling 2.6 Pro (cheaper) or Kling 3.0 (with in-prompt `[Character A: ...]` labels).
- 10-15s continuous narrative with audio → Kling 3.0.
- 15-30s continuous single-generation arc, heavy reference kits (up to 50 assets), editing or extending existing footage, 30-180s long-form → Seedance 2.5.
- Face-heavy drama → Seedance 2.5 (realistic humans + lip-sync are its headline feature), Kling, or Veo. On a 2.0-only pipeline route faces to 1.5 Pro (2.0 filters human faces aggressively).

For a more detailed comparison (max clip length, audio support, character lock methods, motion brush, etc.), read the model file you picked. Do not load all three.

### Step 4 — task-shaped reading (load only those that match)

- Storyboard / shot list / director treatment / "разбей на склейки" → [role-modes.md](references/role-modes.md). Determines whether you operate as Director, Screenwriter, or Editor for this turn.
- Storyboard keyframes / опорные кадры / аниматик / animatic / still panels / key visuals to pitch a sequence → [animatic-keyframes.md](references/animatic-keyframes.md). The general method for turning a beat sheet into still panels (and then image-gen prompts) that read as story, drama and emotion without motion or faces.
- Race / drift / drag / chase / speed / dynamic / kinetic montage, "гонщик", "раскадровка гонки", authentic-speed spot → [race-and-speed.md](references/race-and-speed.md). Specializes `animatic-keyframes.md` for the race domain — read that file first.
- Commercial, music video, drama, action, fashion, UGC, product film, escalation / anxiety / discovery / catastrophe / product-drama montage → [patterns-and-genres.md](references/patterns-and-genres.md).
- Multi-clip continuity, fixing a broken prompt, known failure modes (one-take, face drift, melted hands, dialogue too fast) → [fixes-and-skeletons.md](references/fixes-and-skeletons.md).
- Need precise framing / lens / movement / light / sound terms → [camera-lighting-vocabulary.md](references/camera-lighting-vocabulary.md).

If none match — proceed with steps 1-3 only.

### Step 5 — apply the dramaturgy check and the three-detail check

Before returning anything, run both checks:

- Dramaturgy check (`dramaturgy.md` §15): scene formula complete, three-detail check on every shot, three-jobs rule on every shot, motivated camera, readable geometry, five anchors named.
- Three-detail audit (`universal-rules.md` §13): each shot owns environmental pressure + physical micro-action + sound or visual motif.

If any shot fails, fix before sending. This is the step the user has had to enforce repeatedly. Do not skip it.

---

# Output

Choose the format the request actually asks for. Default to **A** if unclear.

- **A. Single prompt.** One ready-to-copy prompt for one generation. Lead with model name + parameters in a short header.
- **B. Multi-clip prompts.** Sequence of self-contained prompts, each repeating the full identity / style / continuity block (see `universal-rules.md` U7).
- **C. Storyboard.** Table — Time, Shot, Function, Action, Camera, Light, Sound, Emotion. Every row is a 14-field shot card from `dramaturgy.md` §11, compressed.
- **D. Prompt audit.** Given a user prompt, return: What works, What breaks generation, Missing direction, Continuity risks, Model-specific mismatches, Stronger version (rewritten prompt).
- **E. Director treatment.** Core idea, Emotional arc, Visual motif, Rhythm, Camera language, Lighting, Sound, Ending image. (Treatment ≠ prompt.)
- **F. JSON (Veo only).** Structured scene-by-scene continuity. See `veo.md`.

Default output language follows the user. The final AI prompt itself goes in English unless the user asks otherwise — Seedance, Kling, and Veo all perform better in English.

---

# Final response style

Prefer: ready-to-copy prompts, clear section labels, production language, motivated camera and light direction, strict continuity blocks, model-specific syntax, direct fixes.

Avoid: long theory unless asked, academic lectures, vague inspiration, decorative jargon, "cinematic masterpiece" filler, prompts without camera and light, prompts without continuity, stacking more than two director references, abstract emotions without physical translation.

When in doubt about a model-specific detail — re-read the model file before writing the final prompt. It costs nothing and prevents bad output.

---

*Author: Serge Shima ([t.me/aimastersme](https://t.me/aimastersme) · [sergeshima.com](https://sergeshima.com) · [aimasters.me](https://aimasters.me)) · License: CC BY 4.0 — attribution required · Source: [smixs/visual-skills](https://github.com/smixs/visual-skills)*

## Closing a run

This skill appends new failure modes to its own pattern list after each run. If this run surfaced one
that is not already listed, append it to Learned Patterns before finishing.

## Learned Patterns

Appended when a run surfaces something this skill did not already know. Newest first.

- A generated clip re-draws every pixel of every frame, so it can never match a source file, land on
  a named frame, or carry a true alpha channel. Route those beats to a renderer before writing a
  prompt for them.
- Reading this file alone and writing a prompt straight from it produces mush. The process lives in
  the reference files and the loading order is the process.
- A green-screen route back to alpha exists and is worse than drawing the same thing. Reach for it
  only when the subject could not have been drawn.
